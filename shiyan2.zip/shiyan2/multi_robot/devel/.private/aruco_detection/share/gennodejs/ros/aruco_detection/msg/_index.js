
"use strict";

let aruco_info = require('./aruco_info.js');

module.exports = {
  aruco_info: aruco_info,
};
