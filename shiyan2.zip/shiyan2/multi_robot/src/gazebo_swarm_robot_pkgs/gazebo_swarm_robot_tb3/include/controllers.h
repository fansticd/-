/**
 * @file controllerBase.h
 * @brief 编队控制器基类，封装通用逻辑（状态更新、避障、收敛检测）
 */

#pragma once

#include <ros/ros.h>
#include <Eigen/Dense>
#include <vector>
#include <array>
#include <cmath>

// 根据编译环境选择引用的头文件
#include "gazebo_swarm_robot_control.h"

// ==========================================
// 参数结构体
// ==========================================
// Formation Params
// struct ControlParams {
//     double k_p = 1.0;        // 比例增益 (弹性系数)
//     double k_d = 0.5;        // 微分增益 (阻尼系数)
//     double spacing = 0.55;    // 编队期望间距
//     double conv_th = 0.05;   // 收敛位置误差阈值
// };

// struct SafetyParams {
//     // --- 机器人间避障 ---
//     double col_dist = 0.35;      // 避障触发距离 (稍微加大一点)
//     double min_safe_dist = 0.15; // 物理极小距离 (机器人的物理半径，绝对不能小于此值)
//     double k_col = 100;          // 势场增益 (注意：反比例函数的系数通常较小)
    
//     // --- 边界保护 ---
//     double buffer_zone = 0.2;   // 边界缓冲带宽度 (进入此范围开始减速/反弹)
//     double k_bound = 2.0;        // 边界势场增益
    
//     // --- 通用 ---
//     double max_force = 55.0;     // 力的幅值上限 (防止距离接近0时力变为无穷大)

//     struct Bounds {
//         double x_min = -1.966;
//         double x_max = 1.308;
//         double y_min = -0.997;
//         double y_max = 0.758;
//     } bounds;
// };

struct ControlParams {
    double k_p = 1.0;        // 比例增益 (弹性系数)
    double k_d = 0.5;        // 微分增益 (阻尼系数)
    double spacing = 0.55;    // 编队期望间距
    double conv_th = 0.05;   // 收敛位置误差阈值
};

struct SafetyParams {
    // --- 机器人间避障 ---
    double col_dist = 0.35;      // 避障触发距离 (稍微加大一点)
    double min_safe_dist = 0.15; // 物理极小距离 (机器人的物理半径，绝对不能小于此值)
    double k_col = 100;          // 势场增益 (注意：反比例函数的系数通常较小)
    
    // --- 边界保护 ---
    double buffer_zone = 0.2;   // 边界缓冲带宽度 (进入此范围开始减速/反弹)
    double k_bound = 2.0;        // 边界势场增益
    
    // --- 通用 ---
    double max_force = 55.0;     // 力的幅值上限 (防止距离接近0时力变为无穷大)

    struct Bounds {
        double x_min = -1.966;
        double x_max = 1.308;
        double y_min = -0.997;
        double y_max = 0.758;
    } bounds;
};

enum class FormationShape {
    CIRCLE, // 圆形
    STAR,   // 星形
    WEDGE   // 楔形/V形
};
// ==========================================
// 控制器基类
// ==========================================
class ControllerBase {

public:
    /**
     * @brief 构造函数
     * @param nh ROS句柄
     * @param robot SwarmRobot对象引用（多态的核心）
     * @param robot_ids 机器人ID列表
     */
    ControllerBase(ros::NodeHandle& nh, SwarmRobot& robot, std::vector<int> robot_ids);
    virtual ~ControllerBase() = default;

    /**
     * @brief 执行一次控制循环 (包含状态更新、力计算、执行移动)
     * @return true 如果系统已收敛，false 否则
     */
    bool update();

    /**
     * @brief 停止所有机器人
     */
    void stop();

    /**
     * @brief 重置控制器内部状态 (如微分项、时间戳)
     */
    void reset();

protected:
    // 纯虚函数：子类必须实现具体的编队力计算逻辑
    virtual void calculateFormationForces(Eigen::VectorXd& fx, Eigen::VectorXd& fy) = 0;

    // 通用辅助函数
    void updateState();
    void calculateSafetyForces(Eigen::VectorXd& safe_x, Eigen::VectorXd& safe_y);
    bool checkConvergence(const Eigen::VectorXd& force_x, const Eigen::VectorXd& force_y);

protected:
    ros::NodeHandle& nh_;
    SwarmRobot& swarm_robot_;
    std::vector<int> robot_ids_;
    int robot_num_;

    // 参数
    ControlParams ctl_params_;
    SafetyParams safe_params_;

    // 状态变量
    Eigen::VectorXd cur_x_, cur_y_;
    Eigen::VectorXd last_x_, last_y_;
    Eigen::VectorXd vel_x_, vel_y_;
    
    ros::Time last_time_;
    bool first_loop_;
};

// ==========================================
class ControllerLineForm : public ControllerBase {
public:
    ControllerLineForm(ros::NodeHandle& nh, SwarmRobot& robot, std::vector<int> robot_ids);
    
    // 可选：如果需要动态修改间隔
    void setSpacing(double spacing);

protected:
    // 实现基类的纯虚函数
    void calculateFormationForces(Eigen::VectorXd& fx, Eigen::VectorXd& fy) override;

private:
    void initTopology();

    Eigen::MatrixXd lap_;     // Laplacian Matrix
    Eigen::VectorXd bias_x_;  // Line Formation Bias
};

// ==========================================
class ControllerFormations : public ControllerBase {
public:
    ControllerFormations(ros::NodeHandle& nh, SwarmRobot& robot, std::vector<int> robot_ids);

    /**
     * @brief 切换当前的队形形状
     * @param shape 目标形状枚举
     */
    void setFormation(FormationShape shape);

protected:
    // 实现基类的纯虚函数
    void calculateFormationForces(Eigen::VectorXd& fx, Eigen::VectorXd& fy) override;

private:
    /**
     * @brief 根据 current_shape_ 更新 Laplacian 矩阵和 bias 偏置量
     */
    void updateTopologyAndBias();

    FormationShape current_shape_;
    Eigen::MatrixXd lap_;      // 拉普拉斯矩阵
    Eigen::VectorXd bias_x_;   // X轴偏置
    Eigen::VectorXd bias_y_;   // Y轴偏置 (直线编队通常为0，但复杂队形需要)
};

// ==========================================
class ControllerExp3 : public ControllerBase {
public:
    enum class ExpState {
        IDLE,       // 停止
        FORM_A,     // 形成队形 A (六边形)
        FORM_B,     // 形成队形 B (窄矩阵) - 准备穿越
        NAVIGATE    // 整体移动 (穿越中)
    };

    ControllerExp3(ros::NodeHandle& nh, SwarmRobot& robot, std::vector<int> robot_ids)
        : ControllerBase(nh, robot, robot_ids) 
    {
        state_ = ExpState::IDLE;
        nav_vel_x_ = 0.0;
        updateTopology(ExpState::FORM_A); // 默认拓扑
    }

    // 设置状态机
    void setState(ExpState s) {
        state_ = s;
        updateTopology(state_);
        
        // 状态行为逻辑
        if (state_ == ExpState::NAVIGATE) {
            nav_vel_x_ = 0.3; // 设定前进速度 0.3 m/s
        } else {
            nav_vel_x_ = 0.0;
        }
        ROS_INFO_STREAM("Experiment 3 State Switch: " << (int)state_);
    }

protected:
    void calculateFormationForces(Eigen::VectorXd& fx, Eigen::VectorXd& fy) override {
        // 1. 计算编队保持力 (Formation Holding)
        // u_form = -Kp * (L * x - bias)
        Eigen::VectorXd u_form_x = ctl_params_.k_p * (-lap_ * cur_x_ + bias_x_);
        Eigen::VectorXd u_form_y = ctl_params_.k_p * (-lap_ * cur_y_ + bias_y_);

        // 2. 添加导航前馈速度 (Navigation Feedforward)
        // 使得整个编队在保持形状的同时向前移动
        // 注意：基类 update() 中会减去 kd * vel，所以这里给入力需要补偿阻尼项或者直接作为速度追踪
        // 为简化，这里将其作为附加力场：F_nav = kv * v_des
        double k_nav = 3.0; 
        
        for(int i=0; i<robot_num_; i++) {
            fx(i) = u_form_x(i) + k_nav * nav_vel_x_;
            fy(i) = u_form_y(i); // Y轴无整体漂移
        }
    }

private:
    void updateTopology(ExpState s) {
        // 初始化拉普拉斯矩阵 (6机环形拓扑，保证连通性)
        lap_ = Eigen::MatrixXd::Zero(robot_num_, robot_num_);
        for(int i = 0; i < robot_num_; i++) {
            int next = (i + 1) % robot_num_;
            int prev = (i - 1 + robot_num_) % robot_num_;
            lap_(i, i) = 2;
            lap_(i, next) = -1;
            lap_(i, prev) = -1;
        }

        // 定义期望相对位置
        Eigen::VectorXd des_x(robot_num_);
        Eigen::VectorXd des_y(robot_num_);
        des_x.setZero(); des_y.setZero();

        if (s == ExpState::FORM_B || s == ExpState::NAVIGATE) {
            // === 队形 B：窄矩阵 (穿越模式) ===
            // 目标：通过 60cm 宽度的障碍
            // 策略：2列 x 3行
            // Y轴位置：±0.12m (中心距0.24m，加上机器人半径容差，整体宽约0.54m < 0.6m)
            // X轴间距：0.4m (拉开前后距离防止碰撞)
            
            double col_y = 0.12; 
            double row_x = 0.4;

            // 左列
            des_x(0) = 0;           des_y(0) = col_y;
            des_x(1) = -row_x;      des_y(1) = col_y;
            des_x(2) = -2.0*row_x;  des_y(2) = col_y;
            
            // 右列
            des_x(3) = 0;           des_y(3) = -col_y;
            des_x(4) = -row_x;      des_y(4) = -col_y;
            des_x(5) = -2.0*row_x;  des_y(5) = -col_y;

        } else {
            // === 队形 A：正六边形 (常规模式) ===
            // 6个机器人均匀分布在半径 R 的圆上
            double R = 0.8; 
            for(int i=0; i<robot_num_; i++) {
                double angle = 2.0 * M_PI * i / robot_num_;
                des_x(i) = R * std::cos(angle);
                des_y(i) = R * std::sin(angle);
            }
        }

        // 计算 Bias
        bias_x_ = lap_ * des_x;
        bias_y_ = lap_ * des_y;
    }

    ExpState state_;
    Eigen::MatrixXd lap_;
    Eigen::VectorXd bias_x_, bias_y_;
    double nav_vel_x_;
};