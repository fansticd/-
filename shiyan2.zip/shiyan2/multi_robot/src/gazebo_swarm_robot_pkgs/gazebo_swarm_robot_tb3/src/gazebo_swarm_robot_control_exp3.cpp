/**
 * @file main_exp3.cpp
 * @brief 实验三主入口：6机编队穿越障碍
 */

#include "controllers.h" // 确保包含了上面的 ControllerExp3 类定义
#include <std_srvs/Empty.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <cstdio>

int kbhit(void) {
    struct termios oldt, newt;
    int ch;
    int oldf;
    
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    
    ch = getchar();
    
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    
    if(ch != EOF) {
        ungetc(ch, stdin);
        return 1;
    }
    return 0;
}

// 辅助函数：读取一个字符
char getch() {
    char buf = 0;
    struct termios old = {0};
    if (tcgetattr(0, &old) < 0)
        perror("tcsetattr()");
    old.c_lflag &= ~ICANON;
    old.c_lflag &= ~ECHO;
    old.c_cc[VMIN] = 1;
    old.c_cc[VTIME] = 0;
    if (tcsetattr(0, TCSANOW, &old) < 0)
        perror("tcsetattr ICANON");
    if (read(0, &buf, 1) < 0)
        perror ("read()");
    old.c_lflag |= ICANON;
    old.c_lflag |= ECHO;
    if (tcsetattr(0, TCSADRAIN, &old) < 0)
        perror ("tcsetattr ~ICANON");
    return (buf);
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "swarm_exp3_node");
    ros::NodeHandle nh;

    // 1. 初始化 6 个机器人 ID
    // 实验要求：现在是6个机器人
    std::vector<int> swarm_robot_id{1, 2, 3, 4, 5, 6};

    SwarmRobot robot(swarm_robot_id);
    
    // 实例化实验三专用控制器
    ControllerExp3 controller(nh, robot, swarm_robot_id);

    ros::ServiceClient reset_client = nh.serviceClient<std_srvs::Empty>("/gazebo/reset_world");
    ros::Rate rate(20);

    ROS_INFO("========================================");
    ROS_INFO("Experiment 3: Formation Transform & Obstacle Avoidance");
    ROS_INFO("Robot Count: 6");
    ROS_INFO("----------------------------------------");
    ROS_INFO("Keys:");
    ROS_INFO("  [1] Form A (Hexagon)   - Initial/Restore");
    ROS_INFO("  [2] Form B (Narrow)    - Transform for Gap");
    ROS_INFO("  [3] Move Forward (>>>) - Navigate through Gap");
    ROS_INFO("  [4] Stop & Restore A   - Mission Complete");
    ROS_INFO("  [r] Reset Simulation");
    ROS_INFO("========================================");

    while (ros::ok()) {
        bool reset_sim = false;
        if (kbhit()) {
            char c = getchar(); 
            if (c != '\n' && c != '\r') {
                switch(c) {
                    case '1':
                        ROS_INFO(">> Cmd: Switch to Formation A (Hexagon)");
                        controller.setState(ControllerExp3::ExpState::FORM_A);
                        break;
                    case '2':
                        ROS_INFO(">> Cmd: Switch to Formation B (Narrow Grid)");
                        controller.setState(ControllerExp3::ExpState::FORM_B);
                        break;
                    case '3':
                        ROS_INFO(">> Cmd: START NAVIGATION (Moving Forward)");
                        controller.setState(ControllerExp3::ExpState::NAVIGATE);
                        break;
                    case '4':
                        ROS_INFO(">> Cmd: STOP & Restore Formation A");
                        // 先切回 A 状态会自动停止前馈速度 (由 setState 逻辑保证)
                        controller.setState(ControllerExp3::ExpState::FORM_A);
                        break;
                    case 'r':
                    case 'R':
                        ROS_WARN(">> Cmd: RESET");
                        controller.stop();
                        {
                            std_srvs::Empty srv;
                            reset_client.call(srv);
                        }
                        controller.reset();
                        // 复位后默认为 IDLE 或 FORM_A
                        controller.setState(ControllerExp3::ExpState::IDLE);
                        ros::Duration(0.5).sleep(); 
                        reset_sim = true;
                        break;
                }
            }
        }

        if (reset_sim) continue;

        // 执行控制律
        controller.update();

        ros::spinOnce();
        rate.sleep();
    }

    controller.stop();
    return 0;
}