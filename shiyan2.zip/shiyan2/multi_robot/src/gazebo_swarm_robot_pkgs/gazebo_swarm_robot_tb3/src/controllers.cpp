/**
 * @file controllerBase.cpp
 * @brief 基类通用逻辑实现
 */

#include "controllers.h"
#include <algorithm>

// ==========================================
// 控制器基类实现
// ==========================================
ControllerBase::ControllerBase(ros::NodeHandle& nh, SwarmRobot& robot, std::vector<int> robot_ids)
    : nh_(nh), swarm_robot_(robot), robot_ids_(robot_ids), robot_num_(robot_ids.size()) 
{
    // 初始化状态向量
    cur_x_ = Eigen::VectorXd::Zero(robot_num_);
    cur_y_ = Eigen::VectorXd::Zero(robot_num_);
    last_x_ = Eigen::VectorXd::Zero(robot_num_);
    last_y_ = Eigen::VectorXd::Zero(robot_num_);
    vel_x_ = Eigen::VectorXd::Zero(robot_num_);
    vel_y_ = Eigen::VectorXd::Zero(robot_num_);
    
    first_loop_ = true;
    last_time_ = ros::Time::now();
}

void ControllerBase::reset() {
    first_loop_ = true;
    vel_x_.setZero();
    vel_y_.setZero();
    last_time_ = ros::Time::now();
    ROS_INFO("Controller internal state reset.");
}

void ControllerBase::stop() {
    swarm_robot_.stopRobot();
}

// 核心控制循环
bool ControllerBase::update() {
    // 1. 获取并更新状态
    updateState();

    // 2. 计算编队力 (由子类实现)
    Eigen::VectorXd u_form_x, u_form_y; 
    calculateFormationForces(u_form_x, u_form_y);

    // 3. 计算安全力 (避障+边界缓冲) - 这里的力现在是非常强的非线性力
    Eigen::VectorXd u_safe_x, u_safe_y; 
    calculateSafetyForces(u_safe_x, u_safe_y);

    // 4. 检查收敛 (逻辑不变)
    if (checkConvergence(u_form_x, u_form_y)) {
        return true; 
    }

    // 5. 合成控制律并执行
    for (int i = 0; i < robot_num_; i++) {
        // 标准 PD 控制 + 安全势场
        double ux = u_form_x(i) - (ctl_params_.k_d * vel_x_(i)) + u_safe_x(i);
        double uy = u_form_y(i) - (ctl_params_.k_d * vel_y_(i)) + u_safe_y(i);
        
        // --- [新增] 第6步：硬约束截断 (Hard Safety Constraint) ---
        // 这是最后一道防线，如果在边界边缘且试图向外冲，强制将速度命令置零
        
        double dist_to_xmin = cur_x_(i) - safe_params_.bounds.x_min;
        double dist_to_xmax = safe_params_.bounds.x_max - cur_x_(i);
        double dist_to_ymin = cur_y_(i) - safe_params_.bounds.y_min;
        double dist_to_ymax = safe_params_.bounds.y_max - cur_y_(i);
        
        // 阈值设为极小值，防止浮点误差
        double hard_limit = 0.05; 

        // 如果紧贴左边界 且 命令向左 -> 截断
        if (dist_to_xmin < hard_limit && ux < 0) ux = 0.0;
        // 如果紧贴右边界 且 命令向右 -> 截断
        if (dist_to_xmax < hard_limit && ux > 0) ux = 0.0;
        // 如果紧贴下边界 且 命令向下 -> 截断
        if (dist_to_ymin < hard_limit && uy < 0) uy = 0.0;
        // 如果紧贴上边界 且 命令向上 -> 截断
        if (dist_to_ymax < hard_limit && uy > 0) uy = 0.0;

        // 如果已经出界了（异常情况），施加一个强力的回正速度
        if (cur_x_(i) < safe_params_.bounds.x_min) ux = 0.5;
        if (cur_x_(i) > safe_params_.bounds.x_max) ux = -0.5;
        if (cur_y_(i) < safe_params_.bounds.y_min) uy = 0.5;
        if (cur_y_(i) > safe_params_.bounds.y_max) uy = -0.5;

        swarm_robot_.moveRobotbyU(i, ux, uy);
    }
    
    return false;
}

void ControllerBase::updateState() {
    std::vector<std::array<double, 3>> poses;
    swarm_robot_.getRobotPose(poses);
    
    ros::Time current_time = ros::Time::now();
    double dt = (current_time - last_time_).toSec();
    if (dt < 0.001) dt = 0.05; // 防止除零或首帧错误

    for (int i = 0; i < robot_num_; i++) {
        cur_x_(i) = poses[i][0];
        cur_y_(i) = poses[i][1];
        // std::cout << "Robot_" << robot_ids_[i] << " Pose: x=" << cur_x_(i) << " y=" << cur_y_(i) << std::endl;
    }

    if (first_loop_) {
        vel_x_.setZero();
        vel_y_.setZero();
        first_loop_ = false;
    } else {
        // 差分计算速度 (D项输入)
        vel_x_ = (cur_x_ - last_x_) / dt;
        vel_y_ = (cur_y_ - last_y_) / dt;
    }

    last_x_ = cur_x_;
    last_y_ = cur_y_;
    last_time_ = current_time;
}
void ControllerBase::calculateSafetyForces(Eigen::VectorXd& safe_x, Eigen::VectorXd& safe_y) {
    safe_x = Eigen::VectorXd::Zero(robot_num_);
    safe_y = Eigen::VectorXd::Zero(robot_num_);

    double max_F = safe_params_.max_force; // 力幅值截断，防止NaN

    // A. 机器人间避障 (使用反比例势场)
    // Force = k * (1/(d - d_min) - 1/(d_detect - d_min))
    for(int i = 0; i < robot_num_; i++) {
        for(int j = i + 1; j < robot_num_; j++) {
            double dx = cur_x_(i) - cur_x_(j);
            double dy = cur_y_(i) - cur_y_(j);
            double dist = std::sqrt(dx*dx + dy*dy);
            
            // 如果距离小于检测阈值
            if(dist < safe_params_.col_dist) {
                // 计算有效距离 (减去物理半径保护层)
                // 防止除以0：确保分母至少是一个极小正数
                double effective_dist = std::max(dist - safe_params_.min_safe_dist, 0.001);
                double effective_range = std::max(safe_params_.col_dist - safe_params_.min_safe_dist, 0.001);

                // 斥力公式：F = k * (1/d - 1/R)
                // 这种力在接近 min_safe_dist 时会急剧增加
                double force_mag = safe_params_.k_col * (1.0 / effective_dist - 1.0 / effective_range);
                
                // 限制最大力，防止仿真不稳定
                if (force_mag > max_F) force_mag = max_F;

                double fx = force_mag * (dx / dist);
                double fy = force_mag * (dy / dist);

                safe_x(i) += fx; safe_y(i) += fy;
                safe_x(j) -= fx; safe_y(j) -= fy;
            }
        }
    }

    // B. 边界保护 (Buffer Zone - 预防式)
    // 只有当机器人在边界内，但进入 buffer 区域时才生效
    auto& b = safe_params_.bounds;
    double buf = safe_params_.buffer_zone;

    for(int i = 0; i < robot_num_; i++) {
        double x = cur_x_(i);
        double y = cur_y_(i);

        // --- X轴边界 ---
        // 左边界缓冲带
        if (x > b.x_min && x < b.x_min + buf) {
            double dist = x - b.x_min;
            double force = safe_params_.k_bound * (1.0 / std::max(dist, 0.01) - 1.0 / buf);
            if (force > max_F) force = max_F;
            safe_x(i) += force; // 推向右 (+)
        }
        // 右边界缓冲带
        else if (x < b.x_max && x > b.x_max - buf) {
            double dist = b.x_max - x;
            double force = safe_params_.k_bound * (1.0 / std::max(dist, 0.01) - 1.0 / buf);
            if (force > max_F) force = max_F;
            safe_x(i) -= force; // 推向左 (-)
        }

        // --- Y轴边界 ---
        // 下边界缓冲带
        if (y > b.y_min && y < b.y_min + buf) {
            double dist = y - b.y_min;
            double force = safe_params_.k_bound * (1.0 / std::max(dist, 0.01) - 1.0 / buf);
            if (force > max_F) force = max_F;
            safe_y(i) += force; // 推向上 (+)
        }
        // 上边界缓冲带
        else if (y < b.y_max && y > b.y_max - buf) {
            double dist = b.y_max - y;
            double force = safe_params_.k_bound * (1.0 / std::max(dist, 0.01) - 1.0 / buf);
            if (force > max_F) force = max_F;
            safe_y(i) -= force; // 推向下 (-)
        }
    }
}

bool ControllerBase::checkConvergence(const Eigen::VectorXd& force_x, const Eigen::VectorXd& force_y) {

    for (int i = 0; i < robot_num_; i++) {
        double pos_error_sq = force_x(i)*force_x(i) + force_y(i)*force_y(i);
        // 如果位置误差平方大于阈值的平方，认为未收敛
        // 注意：force_x 实际上包含了位置误差信息 (Kp * err)
        if (pos_error_sq > pow(ctl_params_.conv_th * ctl_params_.k_p, 2)) {
            return false;
        }
    }
    return true;
}


// ==========================================
// 直线编队控制器类
// ==========================================
ControllerLineForm::ControllerLineForm(ros::NodeHandle& nh, SwarmRobot& robot, std::vector<int> robot_ids)
    : ControllerBase(nh, robot, robot_ids) 
{
    initTopology();
}

void ControllerLineForm::setSpacing(double spacing) {
    ctl_params_.spacing = spacing;
    // 重新计算 bias
    initTopology(); 
}

void ControllerLineForm::initTopology() {
    lap_ = Eigen::MatrixXd::Zero(robot_num_, robot_num_);
    
    // 自动生成链式拓扑的拉普拉斯矩阵
    for (int i = 0; i < robot_num_; i++) {
        if (i > 0) {
            lap_(i, i) += 1;
            lap_(i, i - 1) -= 1;
        }
        if (i < robot_num_ - 1) {
            lap_(i, i) += 1;
            lap_(i, i + 1) -= 1;
        }
    }

    // 计算直线编队的偏置量 bias = L * desired_x
    Eigen::VectorXd desired_x(robot_num_);
    for(int i = 0; i < robot_num_; i++) {
        desired_x(i) = i * ctl_params_.spacing;
    }
    bias_x_ = lap_ * desired_x;
}

void ControllerLineForm::calculateFormationForces(Eigen::VectorXd& fx, Eigen::VectorXd& fy) {
    // Line Formation Formula: u = -Kp * (L*x - bias)
    // 根据一致性协议，这里计算的是位置误差项
    
    fx = ctl_params_.k_p * (-lap_ * cur_x_ + bias_x_);
    fy = ctl_params_.k_p * (-lap_ * cur_y_); // Y轴目标对齐，无偏置
}

// ==========================================
// ControllerFormations 
// ==========================================
ControllerFormations::ControllerFormations(ros::NodeHandle& nh, SwarmRobot& robot, std::vector<int> robot_ids)
    : ControllerBase(nh, robot, robot_ids) 
{
    // 默认圆形
    current_shape_ = FormationShape::CIRCLE;
    updateTopologyAndBias();
}

void ControllerFormations::setFormation(FormationShape shape) {
    if (current_shape_ != shape) {
        current_shape_ = shape;
        updateTopologyAndBias();
        ROS_INFO_STREAM("Switched formation to shape ID: " << (int)shape);
    }
}

void ControllerFormations::updateTopologyAndBias() {
    lap_ = Eigen::MatrixXd::Zero(robot_num_, robot_num_);
    
    // 使用全连接拓扑或者环形拓扑以保证图的连通性
    // 这里使用环形拓扑 (Ring Topology): 0-1-2-3-4-0
    for(int i = 0; i < robot_num_; i++) {
        int next = (i + 1) % robot_num_;
        int prev = (i - 1 + robot_num_) % robot_num_;
        
        lap_(i, i) = 2;
        lap_(i, next) = -1;
        lap_(i, prev) = -1;
    }

    // 定义期望位置 (Local Coordinates)
    Eigen::VectorXd des_x(robot_num_);
    Eigen::VectorXd des_y(robot_num_);
    des_x.setZero();
    des_y.setZero();

    double R = ctl_params_.spacing; // 使用 spacing 作为基本尺度参数

    switch (current_shape_) {
        case FormationShape::CIRCLE: 
        {
            // 正五边形 / 圆
            double R_circle = 0.8; 
            for (int i = 0; i < robot_num_; i++) {
                double angle = 2.0 * M_PI * i / robot_num_;
                des_x(i) = R_circle * std::cos(angle);
                des_y(i) = R_circle * std::sin(angle);
            }
            break;
        }
        case FormationShape::STAR:
        {
            // 十字星形 (假设5个机器人)
            // 0号居中，1234四周
            if (robot_num_ >= 5) {
                des_x(0) = 0;       des_y(0) = 0;
                des_x(1) = R;       des_y(1) = 0;
                des_x(2) = -R;      des_y(2) = 0;
                des_x(3) = 0;       des_y(3) = R;
                des_x(4) = 0;       des_y(4) = -R;
            }
            break;
        }
        case FormationShape::WEDGE:
        {
            // V形 / 楔形 (领航者0在最前)
            //   3   4
            //    1 2
            //     0
            if (robot_num_ >= 5) {
                des_x(0) = 0;        des_y(0) = 0;
                des_x(1) = -0.6 * R; des_y(1) = 0.5 * R;
                des_x(2) = -0.6 * R; des_y(2) = -0.5 * R;
                des_x(3) = -1.2 * R; des_y(3) = 1.0 * R;
                des_x(4) = -1.2 * R; des_y(4) = -1.0 * R;
            }
            break;
        }
    }

    // 计算 Bias = L * desired_pos
    // 这样做的原理是：收敛时 L*p = bias => L*p = L*des => L(p-des) = 0
    // 即 p_i - p_j = des_i - des_j，保持相对形状
    bias_x_ = lap_ * des_x;
    bias_y_ = lap_ * des_y;
}

void ControllerFormations::calculateFormationForces(Eigen::VectorXd& fx, Eigen::VectorXd& fy) {
    // u = -Kp * (L*x - bias)
    fx = ctl_params_.k_p * (-lap_ * cur_x_ + bias_x_);
    fy = ctl_params_.k_p * (-lap_ * cur_y_ + bias_y_);
}