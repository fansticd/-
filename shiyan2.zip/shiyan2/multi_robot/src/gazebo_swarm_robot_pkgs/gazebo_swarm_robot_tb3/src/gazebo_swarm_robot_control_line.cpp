/**
 * @file gazebo_swarm_robot_control_line.cpp
 * @brief Gazebo 仿真入口，处理键盘重置与仿真环境特有的 SwarmRobot
 */

// 1. 定义宏，告诉头文件我们需要 Gazebo 版本的 SwarmRobot
#define USE_GAZEBO

#include "controllers.h"
#include <std_srvs/Empty.h> // Gazebo Reset Service
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

int kbhit(void)
{
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if (ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "swarm_robot_control_line_gazebo");
    ros::NodeHandle nh;

    // 定义机器人ID列表
    std::vector<int> swarm_robot_id{1, 2, 3, 4, 5};

    SwarmRobot robot(swarm_robot_id);
    ControllerLineForm controller(nh, robot, swarm_robot_id);

    ros::ServiceClient reset_client = nh.serviceClient<std_srvs::Empty>("/gazebo/reset_world");

    ros::Rate rate(20);
    ROS_INFO("Start Gazebo Line Formation Control...");

    while (ros::ok()) {
        if (kbhit()) {
            char c = getchar();
            if (c == 'r' || c == 'R') {
                ROS_WARN("Resetting Simulation...");
                controller.stop();
                
                std_srvs::Empty srv;
                if (reset_client.call(srv)) {
                    ROS_INFO("World reset successfully.");
                    // 必须重置控制器内部状态 (如微分速度计算)
                    controller.reset(); 
                } else {
                    ROS_ERROR("Failed to call reset service.");
                }
                
                ros::Duration(0.5).sleep(); // 等待Gazebo稳定
                while(kbhit()) getchar();   // 清空缓冲区
                break;
            }
        }

        bool converged = controller.update();
        
        if (converged) {
            ROS_INFO_THROTTLE(2.0, "System Converged.");
            controller.stop();
            break;
        }

        ros::spinOnce();
        rate.sleep();
    }

    controller.stop();
    return 0;
}