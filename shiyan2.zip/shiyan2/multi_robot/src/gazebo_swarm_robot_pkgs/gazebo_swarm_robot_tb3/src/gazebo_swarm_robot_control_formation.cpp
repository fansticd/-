/**
 * @file formation_control_node.cpp
 * @brief Gazebo 仿真入口，包含键盘监听 (c/s/w 切换队形, r 复位)
 */

#define USE_GAZEBO

#include "controllers.h"
#include <std_srvs/Empty.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <cstdio>

// 辅助函数：非阻塞检测键盘输入
int kbhit(void) {
    struct termios oldt, newt;
    int ch;
    int oldf;
    
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    
    ch = getchar();
    
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    
    if(ch != EOF) {
        ungetc(ch, stdin);
        return 1;
    }
    return 0;
}

// 辅助函数：读取一个字符
char getch() {
    char buf = 0;
    struct termios old = {0};
    if (tcgetattr(0, &old) < 0)
        perror("tcsetattr()");
    old.c_lflag &= ~ICANON;
    old.c_lflag &= ~ECHO;
    old.c_cc[VMIN] = 1;
    old.c_cc[VTIME] = 0;
    if (tcsetattr(0, TCSANOW, &old) < 0)
        perror("tcsetattr ICANON");
    if (read(0, &buf, 1) < 0)
        perror ("read()");
    old.c_lflag |= ICANON;
    old.c_lflag |= ECHO;
    if (tcsetattr(0, TCSADRAIN, &old) < 0)
        perror ("tcsetattr ~ICANON");
    return (buf);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "swarm_formation_control");
    ros::NodeHandle nh;

    // 1. 初始化
    // 定义机器人ID列表 (假设5个机器人)
    std::vector<int> swarm_robot_id{1, 2, 3, 4, 5};

    SwarmRobot robot(swarm_robot_id);
    
    // 使用新增的 ControllerFormations
    ControllerFormations controller(nh, robot, swarm_robot_id);

    // Gazebo 复位服务客户端
    ros::ServiceClient reset_client = nh.serviceClient<std_srvs::Empty>("/gazebo/reset_world");

    ros::Rate rate(20);
    ROS_INFO("========================================");
    ROS_INFO("Start Formation Control Node");
    ROS_INFO("Keys:");
    ROS_INFO("  [c] + Enter : Circle Formation");
    ROS_INFO("  [s] + Enter : Star Formation");
    ROS_INFO("  [w] + Enter : Wedge (V) Formation");
    ROS_INFO("  [r] + Enter : Reset Simulation (GAZEBO)");
    ROS_INFO("========================================");

    while (ros::ok()) {
        // 2. 键盘监听逻辑
        bool reset = false;
        if (kbhit()) {
            char c = getchar(); 
            if (c != '\n' && c != '\r') {
                switch(c) {
                    case 'c':
                    case 'C':
                        ROS_INFO("Command: Switch to CIRCLE");
                        controller.setFormation(FormationShape::CIRCLE);
                        break;
                    
                    case 's':
                    case 'S':
                        ROS_INFO("Command: Switch to STAR");
                        controller.setFormation(FormationShape::STAR);
                        break;
                    
                    case 'w':
                    case 'W':
                        ROS_INFO("Command: Switch to WEDGE");
                        controller.setFormation(FormationShape::WEDGE);
                        break;

                    case 'r':
                    case 'R':
                        // === 区分开的复位逻辑 ===
                        ROS_WARN("Command: RESET SIMULATION");
                        controller.stop();
                        
                        // 1. 调用 Gazebo 复位服务
                        {
                            std_srvs::Empty srv;
                            if (reset_client.call(srv)) {
                                ROS_INFO("Gazebo world reset.");
                            } else {
                                ROS_ERROR("Failed to call reset service.");
                            }
                        }

                        // 2. 重置控制器内部状态 (清空历史误差、速度记录)
                        controller.reset();
                        
                        // 3. 简单的延时，等待模型落地稳定
                        ros::Duration(0.5).sleep(); 
                        reset = true;
                        break;
                    
                    default:
                        // 忽略其他按键
                        break;
                }
            }
        }

        if (reset) {
            break;
        }

        // 3. 执行控制循环
        controller.update();

        ros::spinOnce();
        rate.sleep();
    }

    controller.stop();
    return 0;
}