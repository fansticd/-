/**
 * @file gazebo_swarm_robot_control_line.cpp
 * @brief 任务二：直线编队控制 (PD控制 + 阻尼 + 避障与边界保护)
 * @date 2025-06-03 (Refactored on 2025-12-14)
 * * 核心逻辑：
 * 1. 编队控制：基于拉普拉斯矩阵的共识算法 (Consensus Algorithm)。
 * 2. 动力学优化：引入微分(D)项/阻尼项，消除系统震荡。
 * 3. 安全机制：
 * - 机器人间避障 (基于势场法的斥力)。
 * - 虚拟地理围栏 (边界斥力)。
 */

#include <swarm_robot_control.h>
#include <Eigen/Dense>
#include <vector>
#include <array>
#include <cmath>

// ==========================================
// 参数配置结构体
// ==========================================
struct ControlParams {
    double k_p = 1.0;        // 比例增益 (弹性系数)
    double k_d = 0.5;        // 微分增益 (阻尼系数)
    double spacing = 0.5;    // 编队期望间距
    double conv_th = 0.04;   // 收敛位置误差阈值
};

struct SafetyParams {
    double col_dist = 0.22;   // 触发避障的距离阈值
    double k_col = 35.0;     // 避障斥力增益
    double k_bound = 5.0;    // 边界斥力增益

    // 安全围栏定义 (Safe Inscribed Rectangle)
    struct Bounds {
        double x_min = -1.966;
        double x_max = 1.308;
        double y_min = -0.997;
        double y_max = 0.758;
    } bounds;
};

// ==========================================
// 编队控制器类
// ==========================================
class LineFormationController {
public:
    LineFormationController(ros::NodeHandle& nh, std::vector<int> ids) 
        : nh_(nh), robot_ids_(ids), swarm_robot_(ids) {
        
        robot_num_ = robot_ids_.size();
        reset_client_ = nh_.serviceClient<std_srvs::Empty>("/gazebo/reset_world");
        
        // 初始化状态向量
        cur_x_ = Eigen::VectorXd::Zero(robot_num_);
        cur_y_ = Eigen::VectorXd::Zero(robot_num_);
        last_x_ = Eigen::VectorXd::Zero(robot_num_);
        last_y_ = Eigen::VectorXd::Zero(robot_num_);
        vel_x_ = Eigen::VectorXd::Zero(robot_num_);
        vel_y_ = Eigen::VectorXd::Zero(robot_num_);

        initTopology(); // 初始化图拓扑
    }

    void run() {
        ROS_INFO("Start Line Formation Control (PD + Safety Mode)...");
        ros::Rate rate(20); // 20Hz loop (approx 0.05s)
        last_time_ = ros::Time::now();

        while (ros::ok()) {
            // 1. 获取并更新状态 (位置与速度)
            updateState();

            // 2. 计算各部分控制力
            Eigen::VectorXd u_form_x, u_form_y; // 编队力
            Eigen::VectorXd u_safe_x, u_safe_y; // 安全力 (避障+边界)
            
            calculateFormationForces(u_form_x, u_form_y);
            calculateSafetyForces(u_safe_x, u_safe_y);

            // 3. 检查收敛
            if (checkConvergence(u_form_x, u_form_y)) {
                ROS_INFO_THROTTLE(2.0, "System Converged. Maintaining State.");
                swarm_robot_.stopRobot();
                break; // 或者是继续保持位置，原代码逻辑是 break
            }

            // 4. 合成最终控制量并执行
            // Control Law: u = (Kp * e) - (Kd * v) + Safety
            for (int i = 0; i < robot_num_; i++) {
                double ux = u_form_x(i) - (ctl_params_.k_d * vel_x_(i)) + u_safe_x(i);
                double uy = u_form_y(i) - (ctl_params_.k_d * vel_y_(i)) + u_safe_y(i);
                
                swarm_robot_.moveRobotbyU(i, ux, uy);
            }

            rate.sleep();
        }
        
        swarm_robot_.stopRobot();
    }

private:
    ros::NodeHandle nh_;
    ros::ServiceClient reset_client_;
    SwarmRobot swarm_robot_;
    std::vector<int> robot_ids_;
    int robot_num_;

    // 参数
    ControlParams ctl_params_;
    SafetyParams safe_params_;

    // 拓扑与偏置
    Eigen::MatrixXd lap_;     // Laplacian Matrix
    Eigen::VectorXd bias_x_;  // Line Formation Bias

    // 状态变量
    Eigen::VectorXd cur_x_, cur_y_;
    Eigen::VectorXd last_x_, last_y_;
    Eigen::VectorXd vel_x_, vel_y_;
    
    ros::Time last_time_;
    bool first_loop_ = true;

    // --------------------------------------------------------
    // 初始化拓扑结构 (Laplacian & Bias)
    // --------------------------------------------------------
    void initTopology() {
        lap_ = Eigen::MatrixXd::Zero(robot_num_, robot_num_);
        
        // 自动生成链式拓扑的拉普拉斯矩阵
        for (int i = 0; i < robot_num_; i++) {
            if (i > 0) {
                lap_(i, i) += 1;
                lap_(i, i - 1) -= 1;
            }
            if (i < robot_num_ - 1) {
                lap_(i, i) += 1;
                lap_(i, i + 1) -= 1;
            }
        }

        // 计算直线编队的偏置量 bias = L * desired_x
        Eigen::VectorXd desired_x(robot_num_);
        for(int i = 0; i < robot_num_; i++) {
            desired_x(i) = i * ctl_params_.spacing;
        }
        bias_x_ = lap_ * desired_x;
    }

    void updateState() {
        std::vector<std::array<double, 3>> poses;
        swarm_robot_.getRobotPose(poses);
        
        ros::Time current_time = ros::Time::now();
        double dt = (current_time - last_time_).toSec();
        if (dt < 0.001) dt = 0.05; // 防止除零或首帧错误

        for (int i = 0; i < robot_num_; i++) {
            cur_x_(i) = poses[i][0];
            cur_y_(i) = poses[i][1];
        }

        if (first_loop_) {
            vel_x_.setZero();
            vel_y_.setZero();
            first_loop_ = false;
        } else {
            // 差分计算速度 (D项输入)
            vel_x_ = (cur_x_ - last_x_) / dt;
            vel_y_ = (cur_y_ - last_y_) / dt;
        }

        last_x_ = cur_x_;
        last_y_ = cur_y_;
        last_time_ = current_time;
    }

    // --------------------------------------------------------
    // 计算编队共识力 (PD中的P项)
    // --------------------------------------------------------
    void calculateFormationForces(Eigen::VectorXd& fx, Eigen::VectorXd& fy) {
        // Line Formation Formula: u = -Kp * (L*x - bias)
        // 注意：这里计算的是误差项 (del_x)，外部会乘以 Kp
        
        fx = ctl_params_.k_p * (-lap_ * cur_x_ + bias_x_);
        fy = ctl_params_.k_p * (-lap_ * cur_y_); // Y轴目标对齐，无偏置
    }

    // --------------------------------------------------------
    // 计算安全保护力 (避障 + 边界)
    // --------------------------------------------------------
    void calculateSafetyForces(Eigen::VectorXd& safe_x, Eigen::VectorXd& safe_y) {
        safe_x = Eigen::VectorXd::Zero(robot_num_);
        safe_y = Eigen::VectorXd::Zero(robot_num_);

        // A. 机器人间避障 (Inter-robot Collision Avoidance)
        for(int i = 0; i < robot_num_; i++) {
            for(int j = i + 1; j < robot_num_; j++) {
                double dx = cur_x_(i) - cur_x_(j);
                double dy = cur_y_(i) - cur_y_(j);
                double dist = std::sqrt(dx*dx + dy*dy);
                
                if(dist < safe_params_.col_dist && dist > 0.001) {
                    double force = safe_params_.k_col * (safe_params_.col_dist - dist);
                    double fx = force * (dx / dist);
                    double fy = force * (dy / dist);

                    safe_x(i) += fx; safe_y(i) += fy;
                    safe_x(j) -= fx; safe_y(j) -= fy;
                }
            }
        }

        // B. 边界保护 (Boundary Protection)
        auto& b = safe_params_.bounds;
        for(int i = 0; i < robot_num_; i++) {
            if (cur_x_(i) < b.x_min) safe_x(i) += safe_params_.k_bound * (b.x_min - cur_x_(i));
            if (cur_x_(i) > b.x_max) safe_x(i) += safe_params_.k_bound * (b.x_max - cur_x_(i));
            if (cur_y_(i) < b.y_min) safe_y(i) += safe_params_.k_bound * (b.y_min - cur_y_(i));
            if (cur_y_(i) > b.y_max) safe_y(i) += safe_params_.k_bound * (b.y_max - cur_y_(i));
        }
    }

    // --------------------------------------------------------
    // 检查系统是否收敛
    // --------------------------------------------------------
    bool checkConvergence(const Eigen::VectorXd& force_x, const Eigen::VectorXd& force_y) {
        for (int i = 0; i < robot_num_; i++) {
            
            double pos_error_sq = force_x(i)*force_x(i) + force_y(i)*force_y(i);
            double vel_energy = vel_x_(i)*vel_x_(i) + vel_y_(i)*vel_y_(i);
            
            if (pos_error_sq > pow(ctl_params_.conv_th, 2)) {
                return false;
            }
        }
        return true;
    }
};

// ==========================================
// Main Function
// ==========================================
int main(int argc, char **argv)
{
    ros::init(argc, argv, "swarm_robot_control_line_damping");
    ros::NodeHandle nh;

    // 定义机器人ID列表
    std::vector<int> swarm_robot_id{1, 2, 3, 4, 5};

    // 实例化并运行控制器
    LineFormationController controller(nh, swarm_robot_id);
    controller.run();

    return 0;
}